#include <stdio.h>
#include <string.h>

void busqueda_directa(char* pat, char* txt)
{
    int M = strlen(pat);
    int N = strlen(txt);

    /* Un bucle para deslizar pat[] uno a uno */
    for (int i = 0; i <= N - M; i++) {
        int j;

        /* Para el �ndice actual i, comprobar si coincide el patr�n */
        for (j = 0; j < M; j++)
            if (txt[i + j] != pat[j])
                break;

        if (j== M) // sipat[0...M-1] = txt[i, i+1, ...i+M-1]
            printf("Patron encontrado en el indice %d \n", i);
    }
}

// Driver's code
int main()
{
    char txt[] = "AABAACAADAABAAABAA";
    char pat[] = "AABA";

      // Funccion llamada
    busqueda_directa(pat, txt);
    return 0;
}
